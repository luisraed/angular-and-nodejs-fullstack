import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-listing-detail-page',
  templateUrl: './listing-detail-page.component.html',
  styleUrls: ['./listing-detail-page.component.css']
})
export class ListingDetailPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
