import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-my-listings-page',
  templateUrl: './my-listings-page.component.html',
  styleUrls: ['./my-listings-page.component.css']
})
export class MyListingsPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
